package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ram_boost_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_THRESHOLD_PERCENT = "key_threshold_percent"
        private const val KEY_AUTO_BOOST_ENABLED = "key_auto_boost_enabled"
        private const val KEY_THRESHOLD_ALERT_ENABLED = "key_threshold_alert_enabled"
        private const val KEY_AUTO_BOOST_INTERVAL = "key_auto_boost_interval"
        private const val KEY_WHITELISTED_PACKAGES = "key_whitelisted_packages"
        private const val KEY_PERIODIC_CLEAN_ENABLED = "key_periodic_clean_enabled"
        private const val KEY_PERIODIC_CLEAN_INTERVAL_MINS = "key_periodic_clean_interval_mins"
    }

    var isPeriodicCleanEnabled: Boolean
        get() = prefs.getBoolean(KEY_PERIODIC_CLEAN_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_PERIODIC_CLEAN_ENABLED, value).apply()

    var periodicCleanIntervalMins: Int
        get() = prefs.getInt(KEY_PERIODIC_CLEAN_INTERVAL_MINS, 3)
        set(value) = prefs.edit().putInt(KEY_PERIODIC_CLEAN_INTERVAL_MINS, value).apply()

    var thresholdPercent: Int
        get() = prefs.getInt(KEY_THRESHOLD_PERCENT, 75)
        set(value) = prefs.edit().putInt(KEY_THRESHOLD_PERCENT, value).apply()

    var isAutoBoostEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_BOOST_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_BOOST_ENABLED, value).apply()

    var isThresholdAlertEnabled: Boolean
        get() = prefs.getBoolean(KEY_THRESHOLD_ALERT_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_THRESHOLD_ALERT_ENABLED, value).apply()

    var autoBoostIntervalMinutes: Int
        get() = prefs.getInt(KEY_AUTO_BOOST_INTERVAL, 30)
        set(value) = prefs.edit().putInt(KEY_AUTO_BOOST_INTERVAL, value).apply()

    fun getWhitelistedPackages(): Set<String> {
        return prefs.getStringSet(KEY_WHITELISTED_PACKAGES, emptySet()) ?: emptySet()
    }

    fun setWhitelistedPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_WHITELISTED_PACKAGES, packages).apply()
    }

    fun addWhitelistedPackage(packageName: String) {
        val current = getWhitelistedPackages().toMutableSet()
        current.add(packageName)
        setWhitelistedPackages(current)
    }

    fun removeWhitelistedPackage(packageName: String) {
        val current = getWhitelistedPackages().toMutableSet()
        current.remove(packageName)
        setWhitelistedPackages(current)
    }

    fun isPackageWhitelisted(packageName: String): Boolean {
        return getWhitelistedPackages().contains(packageName)
    }
}
