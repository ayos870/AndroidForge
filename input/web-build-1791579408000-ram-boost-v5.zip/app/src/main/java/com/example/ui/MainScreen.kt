package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.DeveloperBoard
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BoostResultDialog
import com.example.ui.components.BoostingInProgressDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.TaskManagerScreen
import com.example.ui.screens.ThresholdSettingsScreen
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.TechCyanPrimary
import com.example.viewmodel.RamBoosterViewModel

enum class NavDestination(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    DASHBOARD("Overview", Icons.Filled.Speed, Icons.Outlined.Speed),
    TASKS("Tasks", Icons.Filled.DeveloperBoard, Icons.Outlined.DeveloperBoard),
    THRESHOLD("Threshold", Icons.Filled.Tune, Icons.Outlined.Tune),
    HISTORY("Logs", Icons.Filled.History, Icons.Outlined.History)
}

@Composable
fun MainScreen(
    viewModel: RamBoosterViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    var currentDestination by rememberSaveable { mutableStateOf(NavDestination.DASHBOARD) }

    val stats by viewModel.memoryStats.collectAsState()
    val processes by viewModel.processList.collectAsState()
    val isLoadingProcesses by viewModel.isLoadingProcesses.collectAsState()
    val isBoosting by viewModel.isBoosting.collectAsState()
    val boostStep by viewModel.boostStep.collectAsState()
    val lastBoostResult by viewModel.lastBoostResult.collectAsState()
    val thresholdPercent by viewModel.thresholdPercent.collectAsState()
    val isAutoBoostEnabled by viewModel.isAutoBoostEnabled.collectAsState()
    val isAlertEnabled by viewModel.isThresholdAlertEnabled.collectAsState()
    val autoBoostIntervalMins by viewModel.autoBoostIntervalMinutes.collectAsState()
    val isPeriodicCleanEnabled by viewModel.isPeriodicCleanEnabled.collectAsState()
    val periodicCleanIntervalMins by viewModel.periodicCleanIntervalMins.collectAsState()
    val periodicCleanSecondsRemaining by viewModel.periodicCleanSecondsRemaining.collectAsState()
    val whitelistedPackages by viewModel.whitelistedPackages.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val logs by viewModel.boostLogs.collectAsState()
    val totalFreedMb by viewModel.totalFreedMb.collectAsState()
    val totalCount by viewModel.totalBoostCount.collectAsState()

    // BackHandler to navigate back to dashboard if user is on secondary screens
    if (currentDestination != NavDestination.DASHBOARD) {
        BackHandler {
            currentDestination = NavDestination.DASHBOARD
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        containerColor = DarkBg,
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                tonalElevation = 8.dp,
                windowInsets = WindowInsets.navigationBars,
                modifier = Modifier
                    .testTag("main_bottom_nav")
            ) {
                NavDestination.entries.forEach { destination ->
                    val isSelected = currentDestination == destination
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentDestination = destination },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) destination.selectedIcon else destination.unselectedIcon,
                                contentDescription = destination.title
                            )
                        },
                        label = {
                            Text(
                                text = destination.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF0F172A),
                            selectedTextColor = TechCyanPrimary,
                            indicatorColor = TechCyanPrimary,
                            unselectedIconColor = Color(0xFF94A3B8),
                            unselectedTextColor = Color(0xFF64748B)
                        ),
                        modifier = Modifier.testTag("nav_item_${destination.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentDestination) {
                NavDestination.DASHBOARD -> {
                    DashboardScreen(
                        stats = stats,
                        thresholdPercent = thresholdPercent,
                        isAutoBoostEnabled = isAutoBoostEnabled,
                        isAlertEnabled = isAlertEnabled,
                        isBoosting = isBoosting,
                        isPeriodicCleanEnabled = isPeriodicCleanEnabled,
                        periodicCleanIntervalMins = periodicCleanIntervalMins,
                        periodicCleanSecondsRemaining = periodicCleanSecondsRemaining,
                        onQuickBoost = { viewModel.quickBoost() },
                        onThresholdChange = { viewModel.updateThreshold(it) },
                        onAutoBoostToggle = { viewModel.toggleAutoBoost(it) },
                        onAlertToggle = { viewModel.toggleThresholdAlert(it) },
                        onTogglePeriodicClean = { viewModel.togglePeriodicClean(it) },
                        onPeriodicIntervalChange = { viewModel.setPeriodicCleanInterval(it) },
                        onNavigateToTasks = { currentDestination = NavDestination.TASKS },
                        onNavigateToThreshold = { currentDestination = NavDestination.THRESHOLD }
                    )
                }

                NavDestination.TASKS -> {
                    TaskManagerScreen(
                        processes = processes,
                        isLoading = isLoadingProcesses,
                        isBoosting = isBoosting,
                        searchQuery = searchQuery,
                        selectedFilter = selectedFilter,
                        onSearchChange = { viewModel.setSearchQuery(it) },
                        onFilterChange = { viewModel.setFilter(it) },
                        onToggleSelect = { viewModel.toggleProcessSelection(it) },
                        onSelectAll = { viewModel.selectAllKillable(it) },
                        onKillSelected = { viewModel.killSelectedProcesses() },
                        onKillSingle = { viewModel.killSingleProcess(it) },
                        onToggleWhitelist = { viewModel.toggleWhitelist(it) },
                        onRefresh = { viewModel.loadProcesses() }
                    )
                }

                NavDestination.THRESHOLD -> {
                    ThresholdSettingsScreen(
                        currentRamPercent = stats.percentUsed,
                        thresholdPercent = thresholdPercent,
                        isAutoBoostEnabled = isAutoBoostEnabled,
                        isAlertEnabled = isAlertEnabled,
                        autoBoostIntervalMins = autoBoostIntervalMins,
                        isPeriodicCleanEnabled = isPeriodicCleanEnabled,
                        periodicCleanIntervalMins = periodicCleanIntervalMins,
                        periodicCleanSecondsRemaining = periodicCleanSecondsRemaining,
                        whitelistedPackages = whitelistedPackages,
                        processes = processes,
                        onThresholdChange = { viewModel.updateThreshold(it) },
                        onAutoBoostToggle = { viewModel.toggleAutoBoost(it) },
                        onAlertToggle = { viewModel.toggleThresholdAlert(it) },
                        onIntervalChange = { viewModel.setAutoBoostInterval(it) },
                        onTogglePeriodicClean = { viewModel.togglePeriodicClean(it) },
                        onPeriodicIntervalChange = { viewModel.setPeriodicCleanInterval(it) },
                        onToggleWhitelist = { viewModel.toggleWhitelist(it) }
                    )
                }

                NavDestination.HISTORY -> {
                    HistoryScreen(
                        logs = logs,
                        totalFreedMb = totalFreedMb ?: 0L,
                        totalCount = totalCount,
                        onClearHistory = { viewModel.clearHistory() }
                    )
                }
            }

            // Dialogs
            if (isBoosting) {
                BoostingInProgressDialog(
                    currentStep = boostStep,
                    onDismiss = {}
                )
            }

            lastBoostResult?.let { result ->
                BoostResultDialog(
                    result = result,
                    onDismiss = { viewModel.dismissBoostResult() }
                )
            }
        }
    }
}
