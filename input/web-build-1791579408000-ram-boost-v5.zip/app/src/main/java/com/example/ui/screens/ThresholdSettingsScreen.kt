package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProcessItem
import com.example.ui.components.PeriodicAutoCleanCard
import com.example.ui.components.ProcessItemRow
import com.example.ui.components.ThresholdSliderCard
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TechMintSecondary

@Composable
fun ThresholdSettingsScreen(
    currentRamPercent: Int,
    thresholdPercent: Int,
    isAutoBoostEnabled: Boolean,
    isAlertEnabled: Boolean,
    autoBoostIntervalMins: Int,
    isPeriodicCleanEnabled: Boolean,
    periodicCleanIntervalMins: Int,
    periodicCleanSecondsRemaining: Int,
    whitelistedPackages: Set<String>,
    processes: List<ProcessItem>,
    onThresholdChange: (Int) -> Unit,
    onAutoBoostToggle: (Boolean) -> Unit,
    onAlertToggle: (Boolean) -> Unit,
    onIntervalChange: (Int) -> Unit,
    onTogglePeriodicClean: (Boolean) -> Unit,
    onPeriodicIntervalChange: (Int) -> Unit,
    onToggleWhitelist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val intervalOptions = listOf(15 to "15m", 30 to "30m", 60 to "1h", 120 to "2h")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
        }

        item {
            Text(
                text = "RAM Threshold & Rules",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            Text(
                text = "Configure memory monitoring thresholds, auto-clean schedules and protected apps",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF94A3B8)
            )
        }

        // Primary Threshold Card
        item {
            ThresholdSliderCard(
                currentRamPercent = currentRamPercent,
                thresholdPercent = thresholdPercent,
                isAutoBoostEnabled = isAutoBoostEnabled,
                isAlertEnabled = isAlertEnabled,
                onThresholdChange = onThresholdChange,
                onAutoBoostToggle = onAutoBoostToggle,
                onAlertToggle = onAlertToggle
            )
        }

        // Automatic Periodic RAM Cleaner Card
        item {
            PeriodicAutoCleanCard(
                isEnabled = isPeriodicCleanEnabled,
                intervalMins = periodicCleanIntervalMins,
                secondsRemaining = periodicCleanSecondsRemaining,
                onToggleEnabled = onTogglePeriodicClean,
                onIntervalChange = onPeriodicIntervalChange
            )
        }

        // Auto Boost Interval Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(DarkSurfaceBorder)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auto_boost_interval_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(TechCyanPrimary.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = "Schedule",
                                tint = TechCyanPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Auto-Boost Cooldown Interval",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Minimum delay between consecutive automated cleanups",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        intervalOptions.forEach { (mins, label) ->
                            val isSelected = autoBoostIntervalMins == mins
                            FilterChip(
                                selected = isSelected,
                                onClick = { onIntervalChange(mins) },
                                label = {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TechCyanPrimary,
                                    selectedLabelColor = Color(0xFF0F172A),
                                    containerColor = DarkSurfaceElevated,
                                    labelColor = Color(0xFFCBD5E1)
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = DarkSurfaceBorder,
                                    selectedBorderColor = TechCyanPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Educational Info Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(DarkSurfaceBorder)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Info",
                        tint = TechCyanPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "How RAM Threshold Works",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "When mobile RAM exceeds your designated threshold (e.g. 75%), background tasks can cause input latency and frame drops. RAM Boost identifies non-essential cached processes and frees memory before your phone lags.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFCBD5E1),
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        // Whitelist / Protected Apps Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Shield",
                        tint = TechMintSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Protected Apps (${whitelistedPackages.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
            Text(
                text = "Protected apps will never be killed during one-tap boost or auto-clean",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF94A3B8),
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        // Whitelisted Items list
        val whitelistedItems = processes.filter { it.isWhitelisted }
        if (whitelistedItems.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(DarkSurfaceBorder)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No protected apps yet. Tap the shield icon on any process in the Task Manager to protect it from being cleared.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(whitelistedItems.size) { index ->
                val item = whitelistedItems[index]
                ProcessItemRow(
                    item = item,
                    onToggleSelect = {},
                    onKill = {},
                    onToggleWhitelist = { onToggleWhitelist(item.packageName) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
