package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TechCyanPrimary = Color(0xFF00E5FF)
val TechCyanLight = Color(0xFF80F1FF)
val TechCyanDark = Color(0xFF00B0FF)

val TechMintSecondary = Color(0xFF00E676)
val TechMintLight = Color(0xFF69F0AE)
val TechMintDark = Color(0xFF00C853)

val TechPurpleAccent = Color(0xFF8C52FF)
val TechWarningAmber = Color(0xFFFFB300)
val TechAlertRed = Color(0xFFFF3D71)

val DarkBg = Color(0xFF0B1220)
val DarkSurface = Color(0xFF141E33)
val DarkSurfaceElevated = Color(0xFF1C2843)
val DarkSurfaceBorder = Color(0xFF28385E)

val LightBg = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFE2E8F0)
val LightSurfaceBorder = Color(0xFFCBD5E1)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val TextMutedLight = Color(0xFF94A3B8)
