package com.example.manager

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.example.data.local.AppDatabase
import com.example.data.local.BoostLogEntity
import com.example.data.local.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Foreground service that keeps the Automatic RAM Cleaner and the
 * threshold Auto-Clean running while the app is minimized or closed.
 */
class AutoCleanService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loopJob: Job? = null

    private val prefs by lazy { PreferencesManager(applicationContext) }
    private val memoryManager by lazy { MemoryManager(applicationContext) }
    private val notificationHelper by lazy { NotificationHelper(applicationContext) }
    private val logDao by lazy { AppDatabase.getDatabase(applicationContext).boostLogDao() }

    private var lastAutoBoostTime = 0L
    private var lastWarningTime = 0L
    private var lastResultText = ""

    companion object {
        @Volatile
        var isRunning: Boolean = false

        /** Starts or stops the service depending on the saved settings. */
        fun sync(context: Context) {
            try {
                val prefs = PreferencesManager(context)
                val intent = Intent(context, AutoCleanService::class.java)
                if (prefs.isPeriodicCleanEnabled || prefs.isAutoBoostEnabled) {
                    ContextCompat.startForegroundService(context, intent)
                } else {
                    context.stopService(intent)
                }
            } catch (_: Exception) {
                // Ignore: the system may refuse to start a service from the background
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val notification = notificationHelper.buildServiceNotification(
                "RAM Boost is running",
                buildStatusText(System.currentTimeMillis())
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NotificationHelper.NOTIFICATION_ID_AUTO_CLEANER,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NotificationHelper.NOTIFICATION_ID_AUTO_CLEANER, notification)
            }
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        isRunning = true
        if (loopJob?.isActive != true) {
            loopJob = scope.launch { runLoop() }
        }
        return START_STICKY
    }

    private suspend fun runLoop() {
        var lastNotificationAt = 0L
        while (true) {
            val periodicOn = prefs.isPeriodicCleanEnabled
            val autoBoostOn = prefs.isAutoBoostEnabled
            if (!periodicOn && !autoBoostOn) {
                stopSelf()
                return
            }

            val now = System.currentTimeMillis()
            val stats = withContext(Dispatchers.IO) { memoryManager.getMemoryStats() }
            var cleaned = false

            // 1. Timer based clean (every N minutes)
            if (periodicOn) {
                val intervalMs = prefs.periodicCleanIntervalMins * 60_000L
                var nextAt = prefs.nextPeriodicCleanAt
                if (nextAt <= 0L) {
                    nextAt = now + intervalMs
                    prefs.nextPeriodicCleanAt = nextAt
                }
                if (now >= nextAt) {
                    prefs.nextPeriodicCleanAt = now + intervalMs
                    runClean("Timer Clean (${prefs.periodicCleanIntervalMins}m)")
                    cleaned = true
                }
            }

            // 2. Threshold based clean
            if (autoBoostOn && stats.percentUsed >= prefs.thresholdPercent) {
                val cooldownMs = prefs.autoBoostIntervalMinutes * 60_000L
                if (now - lastAutoBoostTime >= cooldownMs) {
                    lastAutoBoostTime = now
                    runClean("Threshold Auto-Clean (${stats.percentUsed}%)")
                    cleaned = true
                }
            }

            // 3. High RAM warning notification
            if (prefs.isThresholdAlertEnabled) {
                if (stats.percentUsed >= prefs.thresholdPercent) {
                    if (now - lastWarningTime > 180_000L) {
                        lastWarningTime = now
                        notificationHelper.showHighRamWarning(
                            percentUsed = stats.percentUsed,
                            thresholdPercent = prefs.thresholdPercent,
                            usedFormatted = stats.formattedUsed()
                        )
                    }
                } else if (lastWarningTime != 0L) {
                    lastWarningTime = 0L
                    notificationHelper.cancelHighRamWarning()
                }
            }

            // 4. Keep the status notification fresh
            if (cleaned || now - lastNotificationAt >= 15_000L) {
                lastNotificationAt = now
                notificationHelper.updateServiceNotification(
                    "RAM Boost is running",
                    buildStatusText(now)
                )
            }

            delay(2000)
        }
    }

    private suspend fun runClean(source: String) {
        try {
            val result = memoryManager.boostAll(prefs.getWhitelistedPackages())
            logDao.insertLog(
                BoostLogEntity(
                    timestamp = result.timestamp,
                    freedMb = result.freedMb,
                    beforePercent = result.beforePercent,
                    afterPercent = result.afterPercent,
                    closedTasksCount = result.closedTasksCount,
                    triggerSource = source
                )
            )
            lastResultText = "Last clean freed ${result.freedMb} MB"
        } catch (_: Exception) {
            // Never let one failed clean stop the loop
        }
    }

    private fun buildStatusText(now: Long): String {
        val parts = mutableListOf<String>()
        if (prefs.isPeriodicCleanEnabled) {
            val next = prefs.nextPeriodicCleanAt
            val remaining = if (next > 0L) ((next - now) / 1000L).coerceAtLeast(0L) else 0L
            parts.add(
                "Every ${prefs.periodicCleanIntervalMins}m, next in " +
                    String.format("%02d:%02d", remaining / 60, remaining % 60)
            )
        }
        if (prefs.isAutoBoostEnabled) {
            parts.add("Auto-clean at ${prefs.thresholdPercent}% RAM")
        }
        if (lastResultText.isNotEmpty()) {
            parts.add(lastResultText)
        }
        return parts.joinToString(" · ")
    }

    override fun onDestroy() {
        isRunning = false
        scope.cancel()
        super.onDestroy()
    }
}
