package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BoostLogDao {
    @Query("SELECT * FROM boost_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<BoostLogEntity>>

    @Insert
    suspend fun insertLog(log: BoostLogEntity): Long

    @Query("SELECT SUM(freedMb) FROM boost_logs")
    fun getTotalFreedMb(): Flow<Long?>

    @Query("SELECT COUNT(*) FROM boost_logs")
    fun getTotalBoostCount(): Flow<Int>

    @Query("DELETE FROM boost_logs")
    suspend fun clearAll()
}
