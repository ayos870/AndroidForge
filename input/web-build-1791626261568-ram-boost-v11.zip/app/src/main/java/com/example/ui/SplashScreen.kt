package com.example.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DarkBg
import com.example.ui.theme.TechCyanPrimary
import com.example.ui.theme.TextSecondaryDark
import kotlinx.coroutines.launch

/**
 * Logo screen shown for a moment when the app opens, before the main UI.
 */
@Composable
fun SplashScreen() {
    val scaleAnim = remember { Animatable(0.7f) }
    val alphaAnim = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        launch { scaleAnim.animateTo(1f, tween(700)) }
        launch { alphaAnim.animateTo(1f, tween(600)) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.splash_logo),
            contentDescription = "RAM Boost logo",
            modifier = Modifier
                .size(170.dp)
                .graphicsLayer {
                    scaleX = scaleAnim.value
                    scaleY = scaleAnim.value
                    alpha = alphaAnim.value
                }
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "RAM Boost",
            color = TechCyanPrimary,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.graphicsLayer { alpha = alphaAnim.value }
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Speed up your phone",
            color = TextSecondaryDark,
            fontSize = 14.sp,
            modifier = Modifier.graphicsLayer { alpha = alphaAnim.value }
        )
    }
}
