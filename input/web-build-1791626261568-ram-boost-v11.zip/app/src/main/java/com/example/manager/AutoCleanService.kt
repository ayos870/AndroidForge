package com.example.manager

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.data.local.AppDatabase
import com.example.data.local.BoostLogEntity
import com.example.data.local.PreferencesManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Foreground service that keeps the Automatic RAM Cleaner and the
 * threshold Auto-Clean running while the app is minimized or closed.
 *
 * It is driven by two things: a short loop while the phone is awake, and an
 * exact alarm that wakes the phone and the service even when the screen is off.
 */
class AutoCleanService : Service() {

    // The handler guarantees that no unexpected error can crash the service
    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default + CoroutineExceptionHandler { _, _ -> }
    )
    private var loopJob: Job? = null
    private val tickMutex = Mutex()

    private val prefs by lazy { PreferencesManager(applicationContext) }
    private val memoryManager by lazy { MemoryManager(applicationContext) }
    private val notificationHelper by lazy { NotificationHelper(applicationContext) }
    private val logDao by lazy { AppDatabase.getDatabase(applicationContext).boostLogDao() }

    private var lastAutoBoostTime = 0L
    private var lastWarningTime = 0L
    private var lastResultText = ""
    private var lastNotificationAt = 0L
    private var shownCountdownTarget = 0L

    companion object {
        const val ACTION_TICK = "com.example.action.TICK"

        @Volatile
        var isRunning: Boolean = false

        /** Asks Android to stop restricting this app's battery use in the background. */
        fun requestBatteryExemption(context: Context) {
            try {
                val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                if (!pm.isIgnoringBatteryOptimizations(context.packageName)) {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:" + context.packageName)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                }
            } catch (_: Exception) {
                // Some phones do not offer this screen
            }
        }

        private fun watchdogIntent(context: Context): PendingIntent {
            val intent = Intent(context, ServiceRestartReceiver::class.java)
            return PendingIntent.getBroadcast(
                context,
                77,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /** Sets an exact alarm that wakes the service, even if the system killed it. */
        fun scheduleWatchdog(context: Context, delayMs: Long = 60_000L) {
            try {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val pendingIntent = watchdogIntent(context)
                val triggerAt = System.currentTimeMillis() + delayMs
                try {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
                } catch (_: SecurityException) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
                }
            } catch (_: Exception) {
                // Ignore alarm failures
            }
        }

        fun cancelWatchdog(context: Context) {
            try {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                alarmManager.cancel(watchdogIntent(context))
            } catch (_: Exception) {
                // Ignore
            }
        }

        /** Starts or stops the service depending on the saved settings. */
        fun sync(context: Context, tick: Boolean = false) {
            try {
                val prefs = PreferencesManager(context)
                val intent = Intent(context, AutoCleanService::class.java)
                if (prefs.isPeriodicCleanEnabled || prefs.isAutoBoostEnabled) {
                    if (tick) intent.action = ACTION_TICK
                    ContextCompat.startForegroundService(context, intent)
                } else {
                    context.stopService(intent)
                    cancelWatchdog(context)
                }
            } catch (_: Exception) {
                // Ignore: the system may refuse to start a service from the background
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val notification = notificationHelper.buildServiceNotification(
                "RAM Boost is running",
                buildStatusText(),
                currentCountdownTarget()
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NotificationHelper.NOTIFICATION_ID_AUTO_CLEANER,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NotificationHelper.NOTIFICATION_ID_AUTO_CLEANER, notification)
            }
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        isRunning = true
        scheduleWatchdog(applicationContext)

        if (loopJob?.isActive != true) {
            loopJob = scope.launch {
                while (true) {
                    runTick()
                    delay(2000)
                }
            }
        } else if (intent?.action == ACTION_TICK) {
            // Woken by the alarm: check right now
            scope.launch { runTick() }
        }
        return START_STICKY
    }

    /** One safe check. Never throws, and holds the CPU awake while it works. */
    private suspend fun runTick() {
        var lock: PowerManager.WakeLock? = null
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RamBoost::Tick").apply {
                setReferenceCounted(false)
                acquire(120_000L)
            }
        } catch (_: Exception) {
            // Continue without the lock
        }

        try {
            tickMutex.withLock { doTick() }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // One failed check must never stop the cleaner
        } finally {
            try {
                lock?.let { if (it.isHeld) it.release() }
            } catch (_: Exception) {
                // Ignore
            }
        }
    }

    private suspend fun doTick() {
        val periodicOn = prefs.isPeriodicCleanEnabled
        val autoBoostOn = prefs.isAutoBoostEnabled
        if (!periodicOn && !autoBoostOn) {
            cancelWatchdog(applicationContext)
            stopSelf()
            return
        }

        val now = System.currentTimeMillis()
        val stats = withContext(Dispatchers.IO) { memoryManager.getMemoryStats() }
        var cleaned = false

        // 1. Timer based clean (every N minutes)
        if (periodicOn) {
            val intervalMs = prefs.periodicCleanIntervalMins * 60_000L
            var nextAt = prefs.nextPeriodicCleanAt
            if (nextAt <= 0L) {
                nextAt = now + intervalMs
                prefs.nextPeriodicCleanAt = nextAt
            }
            if (now >= nextAt) {
                prefs.nextPeriodicCleanAt = now + intervalMs
                runClean("Timer Clean (${prefs.periodicCleanIntervalMins}m)")
                cleaned = true
            }
        }

        // 2. Threshold based clean
        if (autoBoostOn && stats.percentUsed >= prefs.thresholdPercent) {
            val cooldownMs = prefs.autoBoostIntervalMinutes * 60_000L
            if (now - lastAutoBoostTime >= cooldownMs) {
                lastAutoBoostTime = now
                runClean("Threshold Auto-Clean (${stats.percentUsed}%)")
                cleaned = true
            }
        }

        // 3. High RAM warning notification
        if (prefs.isThresholdAlertEnabled) {
            if (stats.percentUsed >= prefs.thresholdPercent) {
                if (now - lastWarningTime > 180_000L) {
                    lastWarningTime = now
                    notificationHelper.showHighRamWarning(
                        percentUsed = stats.percentUsed,
                        thresholdPercent = prefs.thresholdPercent,
                        usedFormatted = stats.formattedUsed()
                    )
                }
            } else if (lastWarningTime != 0L) {
                lastWarningTime = 0L
                notificationHelper.cancelHighRamWarning()
            }
        }

        // 4. Keep the status notification fresh (the countdown ticks by itself)
        val countdownTarget = currentCountdownTarget()
        if (cleaned || countdownTarget != shownCountdownTarget || now - lastNotificationAt >= 15_000L) {
            lastNotificationAt = now
            shownCountdownTarget = countdownTarget
            notificationHelper.updateServiceNotification(
                "RAM Boost is running",
                buildStatusText(),
                countdownTarget
            )
        }

        // 5. Arm the alarm for the next check (exactly when the next clean is due)
        val delayMs = if (periodicOn) {
            (prefs.nextPeriodicCleanAt - System.currentTimeMillis()).coerceIn(5_000L, 60_000L)
        } else {
            60_000L
        }
        scheduleWatchdog(applicationContext, delayMs)
    }

    private suspend fun runClean(source: String) {
        try {
            val result = memoryManager.boostAll(prefs.getWhitelistedPackages())
            logDao.insertLog(
                BoostLogEntity(
                    timestamp = result.timestamp,
                    freedMb = result.freedMb,
                    beforePercent = result.beforePercent,
                    afterPercent = result.afterPercent,
                    closedTasksCount = result.closedTasksCount,
                    triggerSource = source
                )
            )
            lastResultText = "Last clean freed ${result.freedMb} MB"
            notificationHelper.showCleanResult(
                freedMb = result.freedMb,
                beforePercent = result.beforePercent,
                afterPercent = result.afterPercent,
                closedTasks = result.closedTasksCount
            )
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Never let one failed clean stop the cleaner
        }
    }

    private fun currentCountdownTarget(): Long {
        return if (prefs.isPeriodicCleanEnabled) prefs.nextPeriodicCleanAt else 0L
    }

    private fun buildStatusText(): String {
        val parts = mutableListOf<String>()
        if (prefs.isPeriodicCleanEnabled) {
            parts.add("Cleans every ${prefs.periodicCleanIntervalMins} min")
        }
        if (prefs.isAutoBoostEnabled) {
            parts.add("Auto-clean at ${prefs.thresholdPercent}% RAM")
        }
        if (lastResultText.isNotEmpty()) {
            parts.add(lastResultText)
        }
        return parts.joinToString(" · ")
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // The app was swiped away from recent apps: make sure we come back quickly
        scheduleWatchdog(applicationContext, 5_000L)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        isRunning = false
        scope.cancel()
        if (!prefs.isPeriodicCleanEnabled && !prefs.isAutoBoostEnabled) {
            cancelWatchdog(applicationContext)
        }
        super.onDestroy()
    }
}
