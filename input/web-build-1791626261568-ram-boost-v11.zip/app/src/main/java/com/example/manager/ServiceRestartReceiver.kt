package com.example.manager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.PreferencesManager

/**
 * Wakes up the cleaner service on the exact alarm, after a phone restart,
 * after an app update, or when the system killed it in the background.
 */
class ServiceRestartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = PreferencesManager(context)
        if (!prefs.isPeriodicCleanEnabled && !prefs.isAutoBoostEnabled) return

        // Re-arm first, so the chain never breaks even if starting fails
        AutoCleanService.scheduleWatchdog(context)
        AutoCleanService.sync(context, tick = true)
    }
}
