package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.BoostLogEntity
import com.example.data.local.PreferencesManager
import com.example.data.model.BoostResult
import com.example.data.model.MemoryStats
import com.example.data.model.ProcessItem
import com.example.manager.AutoCleanService
import com.example.manager.MemoryManager
import com.example.manager.NotificationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class ProcessFilter {
    ALL,
    BACKGROUND,
    CACHED,
    USER_APPS,
    WHITELISTED
}

class RamBoosterViewModel(application: Application) : AndroidViewModel(application) {

    private val memoryManager = MemoryManager(application)
    private val prefs = PreferencesManager(application)
    private val db = AppDatabase.getDatabase(application)
    private val logDao = db.boostLogDao()
    private val notificationHelper = NotificationHelper(application)

    private val _memoryStats = MutableStateFlow(memoryManager.getMemoryStats())
    val memoryStats: StateFlow<MemoryStats> = _memoryStats.asStateFlow()

    private val _processList = MutableStateFlow<List<ProcessItem>>(emptyList())
    val processList: StateFlow<List<ProcessItem>> = _processList.asStateFlow()

    private val _isLoadingProcesses = MutableStateFlow(false)
    val isLoadingProcesses: StateFlow<Boolean> = _isLoadingProcesses.asStateFlow()

    private val _isBoosting = MutableStateFlow(false)
    val isBoosting: StateFlow<Boolean> = _isBoosting.asStateFlow()

    private val _boostStep = MutableStateFlow("")
    val boostStep: StateFlow<String> = _boostStep.asStateFlow()

    private val _lastBoostResult = MutableStateFlow<BoostResult?>(null)
    val lastBoostResult: StateFlow<BoostResult?> = _lastBoostResult.asStateFlow()

    private val _thresholdPercent = MutableStateFlow(prefs.thresholdPercent)
    val thresholdPercent: StateFlow<Int> = _thresholdPercent.asStateFlow()

    private val _isAutoBoostEnabled = MutableStateFlow(prefs.isAutoBoostEnabled)
    val isAutoBoostEnabled: StateFlow<Boolean> = _isAutoBoostEnabled.asStateFlow()

    private val _isThresholdAlertEnabled = MutableStateFlow(prefs.isThresholdAlertEnabled)
    val isThresholdAlertEnabled: StateFlow<Boolean> = _isThresholdAlertEnabled.asStateFlow()

    private val _autoBoostIntervalMinutes = MutableStateFlow(prefs.autoBoostIntervalMinutes)
    val autoBoostIntervalMinutes: StateFlow<Int> = _autoBoostIntervalMinutes.asStateFlow()

    private val _isPeriodicCleanEnabled = MutableStateFlow(prefs.isPeriodicCleanEnabled)
    val isPeriodicCleanEnabled: StateFlow<Boolean> = _isPeriodicCleanEnabled.asStateFlow()

    private val _periodicCleanIntervalMins = MutableStateFlow(prefs.periodicCleanIntervalMins)
    val periodicCleanIntervalMins: StateFlow<Int> = _periodicCleanIntervalMins.asStateFlow()

    private val _periodicCleanSecondsRemaining = MutableStateFlow(prefs.periodicCleanIntervalMins * 60)
    val periodicCleanSecondsRemaining: StateFlow<Int> = _periodicCleanSecondsRemaining.asStateFlow()

    private val _whitelistedPackages = MutableStateFlow(prefs.getWhitelistedPackages())
    val whitelistedPackages: StateFlow<Set<String>> = _whitelistedPackages.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilter = MutableStateFlow(ProcessFilter.ALL)
    val selectedFilter: StateFlow<ProcessFilter> = _selectedFilter.asStateFlow()

    // Room DB streams
    val boostLogs: StateFlow<List<BoostLogEntity>> = logDao.getAllLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalFreedMb: StateFlow<Long?> = logDao.getTotalFreedMb()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalBoostCount: StateFlow<Int> = logDao.getTotalBoostCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private var monitorJob: Job? = null
    private var periodicCleanJob: Job? = null
    private var lastWarningNotificationTime: Long = 0L

    init {
        startMemoryMonitoring()
        startPeriodicCleanTimer()
        loadProcesses()

        // Start (or stop) the background service according to saved settings
        AutoCleanService.sync(getApplication<Application>())
    }

    private fun startMemoryMonitoring() {
        monitorJob?.cancel()
        monitorJob = viewModelScope.launch {
            while (isActive) {
                val stats = withContext(Dispatchers.IO) { memoryManager.getMemoryStats() }
                _memoryStats.value = stats

                // The background service handles warnings when it is running
                if (!AutoCleanService.isRunning) {
                    checkHighRamWarningNotification(stats)
                }

                delay(2500)
            }
        }
    }

    private fun checkHighRamWarningNotification(stats: MemoryStats) {
        if (!_isThresholdAlertEnabled.value) return
        val now = System.currentTimeMillis()
        if (stats.percentUsed >= _thresholdPercent.value) {
            if (now - lastWarningNotificationTime > 180_000L) { // 3-minute alert cooldown
                lastWarningNotificationTime = now
                notificationHelper.showHighRamWarning(
                    percentUsed = stats.percentUsed,
                    thresholdPercent = _thresholdPercent.value,
                    usedFormatted = stats.formattedUsed()
                )
            }
        } else {
            if (lastWarningNotificationTime != 0L) {
                lastWarningNotificationTime = 0L
                notificationHelper.cancelHighRamWarning()
            }
        }
    }

    private fun startPeriodicCleanTimer() {
        periodicCleanJob?.cancel()
        periodicCleanJob = viewModelScope.launch {
            var lastRemaining = Int.MAX_VALUE
            while (isActive) {
                if (_isPeriodicCleanEnabled.value) {
                    val nextAt = prefs.nextPeriodicCleanAt
                    val remaining = if (nextAt > 0L) {
                        ((nextAt - System.currentTimeMillis()) / 1000L).toInt().coerceAtLeast(0)
                    } else {
                        _periodicCleanIntervalMins.value * 60
                    }
                    _periodicCleanSecondsRemaining.value = remaining
                    // The service just cleaned in the background: refresh the lists
                    if (remaining > lastRemaining + 5) {
                        loadProcesses()
                    }
                    lastRemaining = remaining
                }
                delay(1000)
            }
        }
    }

    fun loadProcesses() {
        viewModelScope.launch {
            _isLoadingProcesses.value = true
            val procs = memoryManager.getRunningProcesses(_whitelistedPackages.value)
            _processList.value = procs
            _isLoadingProcesses.value = false
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilter(filter: ProcessFilter) {
        _selectedFilter.value = filter
    }

    fun toggleProcessSelection(packageName: String) {
        _processList.value = _processList.value.map {
            if (it.packageName == packageName) it.copy(isSelected = !it.isSelected) else it
        }
    }

    fun selectAllKillable(select: Boolean) {
        _processList.value = _processList.value.map {
            if (!it.isWhitelisted && !it.isSystemApp && it.packageName != getApplication<Application>().packageName) {
                it.copy(isSelected = select)
            } else {
                it
            }
        }
    }

    fun toggleWhitelist(packageName: String) {
        val current = _whitelistedPackages.value.toMutableSet()
        if (current.contains(packageName)) {
            current.remove(packageName)
            prefs.removeWhitelistedPackage(packageName)
        } else {
            current.add(packageName)
            prefs.addWhitelistedPackage(packageName)
        }
        _whitelistedPackages.value = current

        // Update list states
        _processList.value = _processList.value.map {
            if (it.packageName == packageName) {
                val isWhitelisted = current.contains(packageName)
                it.copy(
                    isWhitelisted = isWhitelisted,
                    isSelected = if (isWhitelisted) false else it.isSelected
                )
            } else {
                it
            }
        }
    }

    fun updateThreshold(newThreshold: Int) {
        val clamped = newThreshold.coerceIn(50, 95)
        _thresholdPercent.value = clamped
        prefs.thresholdPercent = clamped
    }

    fun toggleAutoBoost(enabled: Boolean) {
        _isAutoBoostEnabled.value = enabled
        prefs.isAutoBoostEnabled = enabled
        AutoCleanService.sync(getApplication<Application>())
        if (enabled) AutoCleanService.requestBatteryExemption(getApplication<Application>())
    }

    fun toggleThresholdAlert(enabled: Boolean) {
        _isThresholdAlertEnabled.value = enabled
        prefs.isThresholdAlertEnabled = enabled
        if (!enabled) {
            notificationHelper.cancelHighRamWarning()
        }
    }

    fun setAutoBoostInterval(minutes: Int) {
        _autoBoostIntervalMinutes.value = minutes
        prefs.autoBoostIntervalMinutes = minutes
    }

    fun togglePeriodicClean(enabled: Boolean) {
        _isPeriodicCleanEnabled.value = enabled
        prefs.isPeriodicCleanEnabled = enabled
        if (enabled) {
            val totalSecs = _periodicCleanIntervalMins.value * 60
            _periodicCleanSecondsRemaining.value = totalSecs
            prefs.nextPeriodicCleanAt = System.currentTimeMillis() + totalSecs * 1000L
        } else {
            prefs.nextPeriodicCleanAt = 0L
        }
        AutoCleanService.sync(getApplication<Application>())
        if (enabled) AutoCleanService.requestBatteryExemption(getApplication<Application>())
    }

    fun setPeriodicCleanInterval(minutes: Int) {
        val clamped = minutes.coerceIn(1, 120)
        _periodicCleanIntervalMins.value = clamped
        prefs.periodicCleanIntervalMins = clamped
        _periodicCleanSecondsRemaining.value = clamped * 60
        if (_isPeriodicCleanEnabled.value) {
            prefs.nextPeriodicCleanAt = System.currentTimeMillis() + clamped * 60_000L
        }
    }

    fun dismissBoostResult() {
        _lastBoostResult.value = null
    }

    fun clearHistory() {
        viewModelScope.launch {
            logDao.clearAll()
        }
    }

    fun quickBoost() {
        if (_isBoosting.value) return
        viewModelScope.launch {
            _isBoosting.value = true
            _boostStep.value = "Analyzing RAM allocation..."
            delay(400)
            _boostStep.value = "Detecting background processes..."
            delay(500)
            _boostStep.value = "Clearing idle tasks & caches..."

            val result = memoryManager.boostAll(_whitelistedPackages.value)
            delay(350)
            _boostStep.value = "Optimizing VM Heap & reclaiming RAM..."
            delay(400)

            // Save log to DB
            logDao.insertLog(
                BoostLogEntity(
                    timestamp = result.timestamp,
                    freedMb = result.freedMb,
                    beforePercent = result.beforePercent,
                    afterPercent = result.afterPercent,
                    closedTasksCount = result.closedTasksCount,
                    triggerSource = "One-Tap Boost"
                )
            )

            _memoryStats.value = withContext(Dispatchers.IO) { memoryManager.getMemoryStats() }
            _lastBoostResult.value = result
            _isBoosting.value = false
            _boostStep.value = ""

            // Reload process list
            loadProcesses()
        }
    }

    fun killSelectedProcesses() {
        val selectedPackages = _processList.value
            .filter { it.isSelected && !it.isWhitelisted && !it.isSystemApp }
            .map { it.packageName }

        if (selectedPackages.isEmpty()) return

        viewModelScope.launch {
            _isBoosting.value = true
            _boostStep.value = "Closing ${selectedPackages.size} selected tasks..."
            delay(300)

            val result = memoryManager.clearBackgroundProcesses(selectedPackages)

            logDao.insertLog(
                BoostLogEntity(
                    timestamp = result.timestamp,
                    freedMb = result.freedMb,
                    beforePercent = result.beforePercent,
                    afterPercent = result.afterPercent,
                    closedTasksCount = result.closedTasksCount,
                    triggerSource = "Task Manager Kill"
                )
            )

            _memoryStats.value = withContext(Dispatchers.IO) { memoryManager.getMemoryStats() }
            _lastBoostResult.value = result
            _isBoosting.value = false
            _boostStep.value = ""
            loadProcesses()
        }
    }

    fun killSingleProcess(packageName: String) {
        viewModelScope.launch {
            val result = memoryManager.clearBackgroundProcesses(listOf(packageName))
            logDao.insertLog(
                BoostLogEntity(
                    timestamp = result.timestamp,
                    freedMb = result.freedMb,
                    beforePercent = result.beforePercent,
                    afterPercent = result.afterPercent,
                    closedTasksCount = 1,
                    triggerSource = "Process Kill: ${packageName.substringAfterLast('.')}"
                )
            )
            _memoryStats.value = withContext(Dispatchers.IO) { memoryManager.getMemoryStats() }
            _lastBoostResult.value = result
            loadProcesses()
        }
    }
}
