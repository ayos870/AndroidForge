<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/44d2c21e-2b4e-44b1-84c8-1f4302b20e42

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## Background auto-clean reliability update

The periodic schedule is now owned by `AutoCleanerKeepAliveService`, not by the screen's ViewModel. The service runs the periodic `MemoryManager.boostAll(...)` action and writes results to the existing Room history database. A boot/package-replacement receiver attempts to restore the service when periodic cleaning was enabled before restart or app update. The ViewModel countdown is display-only to avoid duplicate cleaning.

For best results on TECNO/HiOS, enable notifications and allow RAM Boost background activity / unrestricted battery use if those settings are available. Android does not allow any ordinary app to guarantee permanent execution: Force stop from system App info, some OEM task-killer modes, denied permissions, and OS restrictions can still stop it. RAM Boost also cannot truly force-close arbitrary apps or guarantee measurable RAM gains on modern Android.

This source update was not compiled in this environment because Gradle and the Gradle wrapper executable are unavailable here. Open the project in Android Studio and sync/build it to verify against your local Android SDK.
