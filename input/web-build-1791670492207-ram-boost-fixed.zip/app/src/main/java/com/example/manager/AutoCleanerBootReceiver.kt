package com.example.manager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.data.local.PreferencesManager

/** Restores the user-enabled schedule after the device finishes booting. */
class AutoCleanerBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED &&
            intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (!PreferencesManager(context.applicationContext).isPeriodicCleanEnabled) return
        try {
            val serviceIntent = Intent(context, AutoCleanerKeepAliveService::class.java).apply {
                action = AutoCleanerKeepAliveService.ACTION_START
            }
            ContextCompat.startForegroundService(context, serviceIntent)
        } catch (_: Exception) {
            // The user can reopen the app if the OS/OEM blocks background startup.
        }
    }
}
