package com.example.manager

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.BoostLogEntity
import com.example.data.local.PreferencesManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Runs the actual periodic schedule independently of the Activity/ViewModel. */
class AutoCleanerKeepAliveService : Service() {
    companion object {
        const val ACTION_START = "com.example.ramboost.START_AUTO_CLEANER"
        const val ACTION_STOP = "com.example.ramboost.STOP_AUTO_CLEANER"
        private const val CHANNEL_ID = "auto_cleaner_foreground"
        private const val NOTIFICATION_ID = 2003
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var scheduleJob: Job? = null
    private lateinit var prefs: PreferencesManager
    private lateinit var memoryManager: MemoryManager
    private lateinit var dao: com.example.data.local.BoostLogDao

    override fun onCreate() {
        super.onCreate()
        prefs = PreferencesManager(applicationContext)
        memoryManager = MemoryManager(applicationContext)
        dao = AppDatabase.getDatabase(applicationContext).boostLogDao()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !prefs.isPeriodicCleanEnabled) {
            scheduleJob?.cancel()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        // Each explicit start refreshes the timer, including when the interval changes.
        startSchedule()
        return START_STICKY
    }

    private fun startSchedule() {
        scheduleJob?.cancel()
        scheduleJob = serviceScope.launch {
            while (isActive) {
                val intervalMs = prefs.periodicCleanIntervalMins.coerceIn(1, 120) * 60_000L
                delay(intervalMs)
                if (!prefs.isPeriodicCleanEnabled) break
                try {
                    val result = memoryManager.boostAll(prefs.getWhitelistedPackages())
                    dao.insertLog(
                        BoostLogEntity(
                            timestamp = result.timestamp,
                            freedMb = result.freedMb,
                            beforePercent = result.beforePercent,
                            afterPercent = result.afterPercent,
                            closedTasksCount = result.closedTasksCount,
                            triggerSource = "Background Timer Clean (${prefs.periodicCleanIntervalMins}m)"
                        )
                    )
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Exception) {
                    // Keep the schedule alive; a failed clean must not permanently end the loop.
                }
            }
            if (!prefs.isPeriodicCleanEnabled) stopSelf()
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("RAM Auto-Cleaner is running")
            .setContentText("Scheduled cleaning is active in the background.")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "RAM Auto-Cleaner Background Service",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        scheduleJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
