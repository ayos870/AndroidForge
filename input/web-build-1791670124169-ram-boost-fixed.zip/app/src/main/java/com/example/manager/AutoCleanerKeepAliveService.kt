package com.example.manager

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.data.local.PreferencesManager

/**
 * Keeps the app process eligible to continue the user-enabled auto-clean schedule
 * while the UI is not visible. Android/OEMs may still stop services in extreme cases.
 */
class AutoCleanerKeepAliveService : Service() {
    companion object {
        const val ACTION_START = "com.example.ramboost.START_AUTO_CLEANER"
        const val ACTION_STOP = "com.example.ramboost.STOP_AUTO_CLEANER"
        private const val CHANNEL_ID = "auto_cleaner_foreground"
        private const val NOTIFICATION_ID = 2003
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP ||
            !PreferencesManager(applicationContext).isPeriodicCleanEnabled) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("RAM Auto-Cleaner is running")
            .setContentText("Automatic cleaning is enabled. Keep this notification visible.")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIFICATION_ID, notification)
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "RAM Auto-Cleaner Background Service",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
