package com.example.manager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.PreferencesManager

/**
 * Wakes up the cleaner service after a phone restart, an app update,
 * or when the system/phone maker killed it in the background.
 */
class ServiceRestartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = PreferencesManager(context)
        if (!prefs.isPeriodicCleanEnabled && !prefs.isAutoBoostEnabled) return

        if (!AutoCleanService.isRunning) {
            AutoCleanService.sync(context)
        }
        AutoCleanService.scheduleWatchdog(context)
    }
}
